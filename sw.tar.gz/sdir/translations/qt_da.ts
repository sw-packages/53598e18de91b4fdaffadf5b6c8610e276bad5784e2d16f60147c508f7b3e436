<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
    <dependencies>
        <dependency catalog="qtbase_da"/>
        <dependency catalog="qtmultimedia_da"/>
    </dependencies>
</TS>
